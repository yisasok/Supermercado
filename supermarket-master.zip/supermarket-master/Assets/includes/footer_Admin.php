<!-- Jquery 3.5.1 -->
<script type="text/javascript" src="<?php echo media() ?>js/plugins/jquery-3.5.1.js"></script>

<!-- Chart 4.3.0 -->
<script type="text/javascript" src="<?php echo media() ?>js/plugins/chart-4.3.0.js"></script>

<!-- Bootstrap min 4.3 -->
<script type="text/javascript" src="<?php echo media() ?>js/plugins/popper.min.js"></script>
<script type="text/javascript" src="<?php echo media() ?>js/plugins/bootstrap.min.js"></script>

<!-- JS DataTable -->
<script type="text/javascript" src="<?php echo media() ?>js/plugins/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo media() ?>js/plugins/dataTables.bootstrap5.min.js"></script>

<script type="text/javascript" src="<?php echo media(); ?>js/plugins/select2.min.js"></script>
<script type="text/javascript" src="<?php echo media(); ?>js/plugins/sweetalert.min.js"></script>
<!-- <script type="text/javascript" src="<?php echo media(); ?>js/plugins/fontawesome-kit_3be261b745.js"></script> -->
<script type="text/javascript" src="<?php echo media(); ?>js/plugins/fontawesome-6.4.0-all.js"></script>
<script type="text/javascript" src="<?php echo media(); ?>js/plugins/html5-qrcode.min.v2.3.0.js"></script>
<script type="text/javascript" src="<?php echo media(); ?>js/plugins/main.js"></script>
<script type="text/javascript" src="<?php echo media(); ?>js/tiff.min.js"></script>
<script type="text/javascript" src="<?php echo media() . $data['page_functions'] ?>"></script>

<script>
     const base_url = "<?= base_url(); ?>";
</script>

</body>

</html>
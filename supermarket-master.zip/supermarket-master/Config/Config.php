<?php
// DEPENDIENDO DEL NOMBRE DEL PROYECTO CAMBIA LA URL
// const base = "http://localhost/supermarket/";
const base = "http://supermarket.net/";
const media = 'assets/';
const libs = "libraries/";
const Views = "views/";
const productosImg = "./assets/images/productos/";
const facturas = "./assets/facturas/";

const host = "localhost;";
const user = "root";
const password = "";
const dbName = "supermarket;";
const conex = "";
const charset = "charset=utf8";

const sucursal = "001";
const terminal = "00001";

date_default_timezone_set("America/Costa_Rica");

// VARIABLES SEPARADORAS DE CANTIDADES
const deci = '.';
const millar = ',';

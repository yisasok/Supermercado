<?php

class HomeModel extends Crud
{
     public function __construct()
     {
          parent::__construct();
     }
}

<?php

class DashboardModel extends Crud
{
     public function __construct()
     {
          parent::__construct();
     }
}
# POS -SuperMarket
## Proyecto ideal para supermercados.

**Modulos de Productos, Clientes, Usuarios, Roles, Ventas y Vista de facturas.**

**Realizado con PHP y patrón de diseño MVC, javascript y jquery**

Dashboard
![Image text](https://github.com/jperez-89/supermarket/blob/master/Assets/images/panel.jpg)

Usuarios
![Image text](https://github.com/jperez-89/supermarket/blob/master/Assets/images/usuarios.jpg)

Clientes
![Image text](https://github.com/jperez-89/supermarket/blob/master/Assets/images/clientes.jpg)

Productos
![Image text](https://github.com/jperez-89/supermarket/blob/master/Assets/images/product.jpg)

Ventas
![Image text](https://github.com/jperez-89/supermarket/blob/master/Assets/images/ventas2.jpg)

Vista General de Facturas
![Image text](https://github.com/jperez-89/supermarket/blob/master/Assets/images/facturas.jpg)

Factura Física
![Image text](https://github.com/jperez-89/supermarket/blob/master/Assets/images/factura%20fisica.jpg)
